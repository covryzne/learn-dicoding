package com.example.submission_1_dicoding_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
