import tensorflow as tf
import keras_tuner as kt
from tensorflow.keras import layers
from tensorflow import keras
from tensorflow.keras import optimizers
from modules.email_spam_transform import transformed_name

# Definisikan input untuk tunner
VOCAB_SIZE = 10000
SEQUENCE_LENGTH = 100
embedding_dim = 16

def model_builder(hp):
    """Build model with hyperparameters for tuning."""
    inputs = tf.keras.Input(shape=(1,), name=transformed_name("message"), dtype=tf.string)
    reshaped_narrative = tf.reshape(inputs, [-1])
    
    # Define hyperparameters for tuning
    vectorize_layer = layers.TextVectorization(
        standardize="lower_and_strip_punctuation",
        max_tokens=VOCAB_SIZE,
        output_mode='int',
        output_sequence_length=SEQUENCE_LENGTH)
    
    x = vectorize_layer(reshaped_narrative)
    x = layers.Embedding(VOCAB_SIZE, embedding_dim)(x)
    x = layers.GlobalAveragePooling1D()(x)
    
    # Hyperparameter tuning for Dense layers
    hp_units_1 = hp.Int('units_1', min_value=32, max_value=128, step=32)
    x = layers.Dense(hp_units_1, activation='relu')(x)
    
    hp_units_2 = hp.Int('units_2', min_value=16, max_value=64, step=16)
    x = layers.Dense(hp_units_2, activation='relu')(x)
    
    outputs = layers.Dense(1, activation='sigmoid')(x)
    model = keras.Model(inputs=inputs, outputs=outputs)
    
    # Compile model with optimizer and loss function
    model.compile(
        loss='binary_crossentropy',
        optimizer=optimizers.Adam(),
        metrics=['accuracy']
    )
    
    return model

def tuner_fn():
    # Menentukan parameter yang ingin di-tune
    def build_model(hp):
        model = tf.keras.Sequential([
            tf.keras.layers.Embedding(input_dim=10000, output_dim=16),
            tf.keras.layers.GlobalAveragePooling1D(),
            tf.keras.layers.Dense(64, activation='relu'),
            tf.keras.layers.Dense(1, activation='sigmoid')
        ])

        model.compile(
            optimizer=tf.keras.optimizers.Adam(
                hp.Float('learning_rate', min_value=1e-5, max_value=1e-2, sampling='LOG')
            ),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        return model

    tuner = kt.RandomSearch(
        build_model,
        objective='val_accuracy',
        max_trials=5,  # Tentukan jumlah percobaan yang ingin dilakukan
        executions_per_trial=3,  # Menentukan jumlah percobaan per trial
        directory='tuner_dir',
        project_name='email_spam_tuning'
    )

    return tuner

# Setelah ini baru jalankan tuner untuk melakukan hyperparameter tuning
def run_tuner(train_set, val_set):
    """Run hyperparameter tuning"""
    tuner = tuner_fn()
    tuner.search(train_set, validation_data=val_set, epochs=10, batch_size=64)
    
    best_model = tuner.get_best_models(num_models=1)[0]
    best_model.summary()  # Tampilkan summary model terbaik
    return best_model
